import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pointofsale',
  templateUrl: './pointofsale.page.html',
  styleUrls: ['./pointofsale.page.scss'],
})
export class PointofsalePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
