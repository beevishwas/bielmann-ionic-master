(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["flashcard-flashcard-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/flashcard/flashcard.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/flashcard/flashcard.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Flashcard</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"container\">\n  <ion-grid >\n    <ion-row >\n      <ion-col size=\"8\">\n        <ion-title style=\"font-size: 14px; padding: 5px;padding-bottom: 10px;\">Question title</ion-title>\n        <ion-row class=\"ans_box\">\n          <span>Question Details</span>\n        </ion-row>\n        <ion-row class=\"image_cont\">\n          <img src=\"assets/images/black_img.jpg\" style=\"width: 100%; height: 200px;\">\n        </ion-row>\n        <ion-row class=\"img_info\">\n          <span>Image Info</span>\n        </ion-row>\n        <ion-row class=\"img_info\">\n          <span>Tags</span>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-row class=\"sol_btn\">\n          <ion-button (click)=\"gologin()\" style=\"width: 300px\">Solution</ion-button>\n        </ion-row>\n        <ion-row class=\"up_down_btn\">\n          <ion-button (click)=\"gologin()\" style=\"width: 120px\">UP</ion-button>\n          <ion-button (click)=\"gologin()\" style=\"width: 120px\">DOWN</ion-button>\n        </ion-row>\n        <ion-row class=\"img_info\">\n          <span>Tags</span>\n        </ion-row>\n        <ion-tab-bar class=\"tabs_con\">\n          <ion-tab-button selected=true>\n            <ion-label>TAB 1</ion-label>\n          </ion-tab-button>\n\n          <ion-tab-button>\n            <ion-label>TAB 2</ion-label>\n          </ion-tab-button>\n\n          <ion-tab-button>\n            <ion-label>TAB 3</ion-label>\n          </ion-tab-button>\n\n          <ion-tab-button>\n            <ion-label>TAB 4</ion-label>\n          </ion-tab-button>\n\n          <ion-tab-button>\n            <ion-label>TAB 4</ion-label>\n          </ion-tab-button>\n\n          <ion-tab-button>\n            <ion-label>TAB 5</ion-label>\n          </ion-tab-button>\n        </ion-tab-bar>\n        <ion-row class=\"question_list\">\n          <span class=\"que_list_item_sel\">Question 1 Question 11Question 1Question 1Question 1Question 1</span>\n          <span class=\"que_list_item\">Question 2</span>\n          <span class=\"que_list_item\">Question 3</span>\n          <span class=\"que_list_item\">Question 4</span>\n          <span class=\"que_list_item\">Question 5</span>\n          <span class=\"que_list_item\">Question 6</span>\n        </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/flashcard/flashcard.module.ts":
/*!***********************************************!*\
  !*** ./src/app/flashcard/flashcard.module.ts ***!
  \***********************************************/
/*! exports provided: FlashcardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlashcardPageModule", function() { return FlashcardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _flashcard_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./flashcard.page */ "./src/app/flashcard/flashcard.page.ts");







const routes = [
    {
        path: '',
        component: _flashcard_page__WEBPACK_IMPORTED_MODULE_6__["FlashcardPage"]
    }
];
let FlashcardPageModule = class FlashcardPageModule {
};
FlashcardPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_flashcard_page__WEBPACK_IMPORTED_MODULE_6__["FlashcardPage"]]
    })
], FlashcardPageModule);



/***/ }),

/***/ "./src/app/flashcard/flashcard.page.scss":
/*!***********************************************!*\
  !*** ./src/app/flashcard/flashcard.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ans_box {\n  margin-top: 10px;\n  font-size: 14px;\n  border-radius: 5px;\n  min-height: 200px;\n  border: 1px solid black;\n  padding: 8px;\n  text-align: start;\n}\n\n.container {\n  -webkit-box-flex: 1;\n          flex: 1;\n  background-color: #f5f4f4;\n}\n\n.image_cont {\n  margin-top: 10px;\n}\n\n.img_info {\n  margin-top: 10px;\n  font-size: 14px;\n  border-radius: 5px;\n  height: 80px;\n  border: 1px solid black;\n  padding: 8px;\n  text-align: start;\n}\n\n.sol_btn {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  align-content: center;\n  margin-top: 10;\n}\n\n.up_down_btn {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n          flex-direction: row;\n  display: -webkit-box;\n  display: flex;\n  justify-content: space-around;\n  margin-top: 30px;\n}\n\n.tabs_con {\n  background-color: white;\n  border: 1px solid gray;\n  margin-top: 10px;\n}\n\n.question_list {\n  margin-top: 10px;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  display: -webkit-box;\n  display: flex;\n  border: 1px solid;\n}\n\n.que_list_item_sel {\n  min-height: 45px;\n  background-color: #27c427;\n  padding: 5px;\n}\n\n.que_list_item {\n  min-height: 45px;\n  padding: 5px;\n  background-color: white;\n  border-bottom: 0.5px gray solid;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmxhc2hjYXJkL0Q6XFxJb25pY1xcQXBwIEludmVudGVyc1xcYmllbG1hbm4taW9uaWMtbWFzdGVyL3NyY1xcYXBwXFxmbGFzaGNhcmRcXGZsYXNoY2FyZC5wYWdlLnNjc3MiLCJzcmMvYXBwL2ZsYXNoY2FyZC9mbGFzaGNhcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FEQ0E7RUFDSSxtQkFBQTtVQUFBLE9BQUE7RUFDQSx5QkFBQTtBQ0VKOztBREFBO0VBQ0UsZ0JBQUE7QUNHRjs7QURBQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDR0Y7O0FEQUE7RUFDRSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0FDR0Y7O0FEQUE7RUFDRSw4QkFBQTtFQUFBLDZCQUFBO1VBQUEsbUJBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSw2QkFBQTtFQUNBLGdCQUFBO0FDR0Y7O0FEQUE7RUFDRSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUNHRjs7QURBQTtFQUNFLGdCQUFBO0VBQ0EsNEJBQUE7RUFBQSw2QkFBQTtVQUFBLHNCQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0VBQ0EsaUJBQUE7QUNHRjs7QURBQTtFQUNJLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FDR0o7O0FEREE7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLCtCQUFBO0FDSUoiLCJmaWxlIjoic3JjL2FwcC9mbGFzaGNhcmQvZmxhc2hjYXJkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hbnNfYm94IHtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgbWluLWhlaWdodDogMjAwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIHRleHQtYWxpZ246IHN0YXJ0O1xyXG59XHJcbi5jb250YWluZXJ7XHJcbiAgICBmbGV4OiAxO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI0NSwgMjQ0LCAyNDQpXHJcbn1cclxuLmltYWdlX2NvbnQge1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5pbWdfaW5mbyB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGhlaWdodDogODBweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XHJcbn1cclxuXHJcbi5zb2xfYnRuIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxuICBtYXJnaW4tdG9wOiAxMDtcclxufVxyXG5cclxuLnVwX2Rvd25fYnRuIHtcclxuICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgbWFyZ2luLXRvcDogMzBweDtcclxufVxyXG5cclxuLnRhYnNfY29uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOndoaXRlO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuLnF1ZXN0aW9uX2xpc3Qge1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkO1xyXG59XHJcblxyXG4ucXVlX2xpc3RfaXRlbV9zZWx7XHJcbiAgICBtaW4taGVpZ2h0OiA0NXB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDM5LCAxOTYsIDM5KTtcclxuICAgIHBhZGRpbmc6IDVweDtcclxufVxyXG4ucXVlX2xpc3RfaXRlbXtcclxuICAgIG1pbi1oZWlnaHQ6IDQ1cHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlci1ib3R0b206IDAuNXB4IGdyYXkgc29saWQ7XHJcbn0iLCIuYW5zX2JveCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtaW4taGVpZ2h0OiAyMDBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XG4gIHBhZGRpbmc6IDhweDtcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XG59XG5cbi5jb250YWluZXIge1xuICBmbGV4OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNGY0O1xufVxuXG4uaW1hZ2VfY29udCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5pbWdfaW5mbyB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBoZWlnaHQ6IDgwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICBwYWRkaW5nOiA4cHg7XG4gIHRleHQtYWxpZ246IHN0YXJ0O1xufVxuXG4uc29sX2J0biB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDEwO1xufVxuXG4udXBfZG93bl9idG4ge1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgbWFyZ2luLXRvcDogMzBweDtcbn1cblxuLnRhYnNfY29uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5xdWVzdGlvbl9saXN0IHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZGlzcGxheTogZmxleDtcbiAgYm9yZGVyOiAxcHggc29saWQ7XG59XG5cbi5xdWVfbGlzdF9pdGVtX3NlbCB7XG4gIG1pbi1oZWlnaHQ6IDQ1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyN2M0Mjc7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLnF1ZV9saXN0X2l0ZW0ge1xuICBtaW4taGVpZ2h0OiA0NXB4O1xuICBwYWRkaW5nOiA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBib3JkZXItYm90dG9tOiAwLjVweCBncmF5IHNvbGlkO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/flashcard/flashcard.page.ts":
/*!*********************************************!*\
  !*** ./src/app/flashcard/flashcard.page.ts ***!
  \*********************************************/
/*! exports provided: FlashcardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlashcardPage", function() { return FlashcardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FlashcardPage = class FlashcardPage {
    constructor() { }
    ngOnInit() {
    }
};
FlashcardPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-flashcard',
        template: __webpack_require__(/*! raw-loader!./flashcard.page.html */ "./node_modules/raw-loader/index.js!./src/app/flashcard/flashcard.page.html"),
        styles: [__webpack_require__(/*! ./flashcard.page.scss */ "./src/app/flashcard/flashcard.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], FlashcardPage);



/***/ })

}]);
//# sourceMappingURL=flashcard-flashcard-module-es2015.js.map