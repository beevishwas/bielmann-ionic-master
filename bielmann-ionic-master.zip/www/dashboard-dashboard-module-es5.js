(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dashboard-dashboard-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/dashboard/dashboard.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/dashboard/dashboard.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Dashboard</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"8\" class=\"image_display\">\n        <ion-row text-center>\n          <ion-col size=\"4\" (click)=\"onFlashCardClick()\">\n            <ion-img src=\"assets/images/flashcard.png\" style=\"height: 80px; margin-bottom: 5px; margin-top: 20px;\">\n            </ion-img>\n            <ion-label>Flashcard</ion-label>\n          </ion-col>\n          <ion-col size=\"4\" (click)=\"onTodoClick()\">\n            <ion-img src=\"assets/images/todo.png\" style=\"height: 80px; margin-bottom: 5px; margin-top: 20px;\">\n            </ion-img>\n            <ion-label>ToDo</ion-label>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-img src=\"assets/images/foram.png\" style=\"height: 80px; margin-bottom: 5px; margin-top: 20px;\">\n            </ion-img>\n            <ion-label>Forum</ion-label>\n          </ion-col>\n          <ion-col size=\"4\" (click)=\"onPOSClick()\">\n            <ion-img src=\"assets/images/poc.png\" style=\"height: 80px; margin-bottom: 5px; margin-top: 20px;\"></ion-img>\n            <ion-label>Point Of Sale</ion-label>\n          </ion-col>\n          <ion-col size=\"4\" (click)=\"onSettings()\">\n            <ion-img src=\"assets/images/settings.png\" style=\"height: 80px; margin-bottom: 5px; margin-top: 20px;\">\n            </ion-img>\n            <ion-label>Settings</ion-label>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-img src=\"assets/images/hr.png\" style=\"height: 80px; margin-bottom: 5px; margin-top: 20px;\"></ion-img>\n            <ion-label>Human Resources</ion-label>\n          </ion-col>\n\n        </ion-row>\n\n      </ion-col>\n      <ion-col size=\"4\">\n        <span class=\"name_display\"> News</span>\n        <ion-row class=\"news_block\">\n          <ion-col size=\"3\" align-self-center>\n            <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n\n          </ion-col>\n          <ion-col size=\"9\" class=\"news_opt\">\n            Iocns\n          </ion-col>\n\n          <ion-col size=\"3\" align-self-center>\n            <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n\n          </ion-col>\n          <ion-col size=\"9\" class=\"news_opt\">\n            Lorem Ip-sumas-dasd\n          </ion-col>\n\n          <ion-col size=\"3\" align-self-center>\n            <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n\n          </ion-col>\n          <ion-col size=\"9\" class=\"news_opt\">\n\n            What is Lorem Ipsumas\n          </ion-col>\n\n          <ion-col size=\"3\" align-self-center>\n            <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n\n          </ion-col>\n          <ion-col size=\"9\" class=\"news_opt\">\n            where can I get some?\n          </ion-col>\n\n          <ion-col size=\"3\" align-self-center>\n            <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n\n          </ion-col>\n          <ion-col size=\"9\" class=\"news_opt\">\n            where dose it come from?\n          </ion-col>\n\n        </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>"

/***/ }),

/***/ "./src/app/dashboard/dashboard.module.ts":
/*!***********************************************!*\
  !*** ./src/app/dashboard/dashboard.module.ts ***!
  \***********************************************/
/*! exports provided: DashboardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardPageModule", function() { return DashboardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _dashboard_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dashboard.page */ "./src/app/dashboard/dashboard.page.ts");







var routes = [
    {
        path: '',
        component: _dashboard_page__WEBPACK_IMPORTED_MODULE_6__["DashboardPage"]
    }
];
var DashboardPageModule = /** @class */ (function () {
    function DashboardPageModule() {
    }
    DashboardPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_dashboard_page__WEBPACK_IMPORTED_MODULE_6__["DashboardPage"]]
        })
    ], DashboardPageModule);
    return DashboardPageModule;
}());



/***/ }),

/***/ "./src/app/dashboard/dashboard.page.scss":
/*!***********************************************!*\
  !*** ./src/app/dashboard/dashboard.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".image_display {\n  height: \"100%\";\n  border: 1px solid;\n}\n\n.news_opt {\n  font-size: 14px;\n  color: gray;\n}\n\n.news_block {\n  margin-top: 17px;\n}\n\n.name_display {\n  margin-left: 5px;\n  color: gray;\n}\n\n.img_display {\n  width: 70%;\n}\n\n.img_opt {\n  font-size: 14px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGFzaGJvYXJkL0Q6XFxJb25pY1xcQXBwIEludmVudGVyc1xcYmllbG1hbm4taW9uaWMtbWFzdGVyL3NyY1xcYXBwXFxkYXNoYm9hcmRcXGRhc2hib2FyZC5wYWdlLnNjc3MiLCJzcmMvYXBwL2Rhc2hib2FyZC9kYXNoYm9hcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQ0VGOztBREFBO0VBQ0UsZ0JBQUE7QUNHRjs7QUREQTtFQUNFLGdCQUFBO0VBQ0EsV0FBQTtBQ0lGOztBRERBO0VBQ0UsVUFBQTtBQ0lGOztBREZBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FDS0YiLCJmaWxlIjoic3JjL2FwcC9kYXNoYm9hcmQvZGFzaGJvYXJkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbWFnZV9kaXNwbGF5IHtcbiAgaGVpZ2h0OiBcIjEwMCVcIjtcbiAgYm9yZGVyOiAxcHggc29saWQ7XG59XG4ubmV3c19vcHQge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLm5ld3NfYmxvY2sge1xuICBtYXJnaW4tdG9wOiAxN3B4O1xufVxuLm5hbWVfZGlzcGxheSB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIGNvbG9yOiBncmF5O1xufVxuXG4uaW1nX2Rpc3BsYXkge1xuICB3aWR0aDogNzAlO1xufVxuLmltZ19vcHQge1xuICBmb250LXNpemU6IDE0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbiIsIi5pbWFnZV9kaXNwbGF5IHtcbiAgaGVpZ2h0OiBcIjEwMCVcIjtcbiAgYm9yZGVyOiAxcHggc29saWQ7XG59XG5cbi5uZXdzX29wdCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6IGdyYXk7XG59XG5cbi5uZXdzX2Jsb2NrIHtcbiAgbWFyZ2luLXRvcDogMTdweDtcbn1cblxuLm5hbWVfZGlzcGxheSB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIGNvbG9yOiBncmF5O1xufVxuXG4uaW1nX2Rpc3BsYXkge1xuICB3aWR0aDogNzAlO1xufVxuXG4uaW1nX29wdCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/dashboard/dashboard.page.ts":
/*!*********************************************!*\
  !*** ./src/app/dashboard/dashboard.page.ts ***!
  \*********************************************/
/*! exports provided: DashboardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardPage", function() { return DashboardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var DashboardPage = /** @class */ (function () {
    function DashboardPage(router) {
        this.router = router;
    }
    // "imgdisplay":
    // [
    //  {
    //    "image": "assets/images/poc.png",
    //   "Name": "Printofsale"
    // },
    // {
    //    "image": "assets/images/settings.png",
    //   "Name": "Printofsale"
    //  },
    // ]
    DashboardPage.prototype.ngOnInit = function () {
    };
    DashboardPage.prototype.onFlashCardClick = function () {
        this.router.navigate(['/flashcard']);
    };
    DashboardPage.prototype.onPOSClick = function () {
        this.router.navigate(['/pointofsale']);
    };
    DashboardPage.prototype.onTodoClick = function () {
        this.router.navigate(['/todo']);
    };
    DashboardPage.prototype.onSettings = function () {
        this.router.navigate(['/settings']);
    };
    DashboardPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    DashboardPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! raw-loader!./dashboard.page.html */ "./node_modules/raw-loader/index.js!./src/app/dashboard/dashboard.page.html"),
            styles: [__webpack_require__(/*! ./dashboard.page.scss */ "./src/app/dashboard/dashboard.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], DashboardPage);
    return DashboardPage;
}());



/***/ })

}]);
//# sourceMappingURL=dashboard-dashboard-module-es5.js.map