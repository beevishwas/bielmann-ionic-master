(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"ion-content\" >\n    <ion-row justify-content-center align-items-center style=\"margin-top: 8px; flex-direction: column\">\n        <ion-title>\n            <img src=\"assets/images/bielmann_app_logo.png\" style=\"width: 180px;\">\n        </ion-title>\n        <ion-row class=\"user_url\">\n            <ion-label class=\"ssl-label\">{{sslValue}}</ion-label>\n            <ion-input placeholder=\"Please enter base url\" type=\"url\" inputmode=\"url\" [(ngModel)]=\"Url\"></ion-input>\n        </ion-row>\n\n        <ion-item> \n            <ion-label class=\"my-label\">SSL Url?</ion-label>\n            <ion-toggle slot=\"end\" color=\"success \" class=\"icon\" [(ngModel)]=\"sslToggled\"\n                (ionChange)=\"ChangeSSLValue()\">\n            </ion-toggle>\n        </ion-item>\n\n        <ion-button shape=\"round\" class=\"user_sub_btn\" (click)=\"gologin()\" style=\"margin-top: 0px\">Submit\n        </ion-button>\n\n    </ion-row>\n</div>"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");








let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["IonicStorageModule"].forRoot(),
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-title {\n  color: white;\n  margin-bottom: 2vh;\n}\n\nion-content {\n  --align-content: center;\n  --display: flex;\n  --flex-direction: column;\n  --align-items: center;\n  --justify-content: center;\n  --height: \"100%\";\n  --ion-background-color: lightgray;\n}\n\n.ion-content {\n  width: 100%;\n  height: 100%;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n  align-content: center;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n}\n\n.Absolute-Center {\n  width: 100%;\n  height: 100%;\n  margin: auto;\n  position: absolute;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n}\n\nion-input .text-input {\n  text-align: left;\n}\n\n.user_url_text {\n  background-color: white;\n  font-size: 10px;\n  text-align: start;\n}\n\n.user_url {\n  background-color: white;\n  font-size: 14px;\n  width: 250px;\n  height: 50px;\n  align-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  border-radius: 30px;\n  border: 1px solid gray;\n  margin-bottom: 5px;\n  padding-left: 8px;\n  text-align: start;\n}\n\n.user_sub_btn {\n  text-transform: capitalize;\n  --background-hover: forestgreen;\n  --background-activated: forestgreen;\n  margin-top: 10px;\n  --background: forestgreen;\n  width: 250px;\n  height: 50px;\n  font-size: 14px;\n}\n\n.middle_display {\n  height: 31px;\n  width: 154px;\n  align-content: center;\n}\n\n.display_url {\n  float: left;\n  font-size: 10px;\n}\n\n.ssl-label {\n  vertical-align: middle;\n  align-self: center;\n}\n\n.icon {\n  --ion-color-base: var(--ion-color-forestgreen, #228b22) !important;\n  --ion-color-shade: var(--ion-color-forestgreen-shade, #228b22) !important;\n  --ion-color-tint: var(--ion-color-forestgreen-tint, #228b22) !important;\n  -webkit-padding-start: 41px;\n          padding-inline-start: 41px;\n}\n\n.colume {\n  height: 29px;\n  /* min-height: 0px; */\n  padding-left: 0px;\n  padding-right: 0px;\n  padding-top: 0px;\n  padding-bottom: 0px;\n}\n\n.my-label {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcSW9uaWNcXEFwcCBJbnZlbnRlcnNcXGJpZWxtYW5uLWlvbmljLW1hc3Rlci9zcmNcXGFwcFxcaG9tZVxcaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURDQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLHdCQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUNBQUE7QUNFRjs7QURDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSxxQkFBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtBQ0VGOztBREFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFFQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0FDRUY7O0FEQ0U7RUFDRSxnQkFBQTtBQ0VKOztBREVBO0VBQ0UsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNDRjs7QURDQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ0VGOztBREFBO0VBQ0UsMEJBQUE7RUFDQSwrQkFBQTtFQUNBLG1DQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0dGOztBREFBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtBQ0dGOztBREFBO0VBQ0UsV0FBQTtFQUNBLGVBQUE7QUNHRjs7QURBQTtFQUNFLHNCQUFBO0VBQ0Esa0JBQUE7QUNHRjs7QURBQTtFQUNFLGtFQUFBO0VBQ0EseUVBQUE7RUFDQSx1RUFBQTtFQUNBLDJCQUFBO1VBQUEsMEJBQUE7QUNHRjs7QUREQTtFQUNFLFlBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDSUY7O0FEREE7RUFDRSxlQUFBO0FDSUYiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRpdGxlIHtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tYm90dG9tOiAydmg7XG59XG5pb24tY29udGVudCB7XG4gIC0tYWxpZ24tY29udGVudDogY2VudGVyO1xuICAtLWRpc3BsYXk6IGZsZXg7XG4gIC0tZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgLS1hbGlnbi1pdGVtczogY2VudGVyO1xuICAtLWp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAtLWhlaWdodDogXCIxMDAlXCI7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcbn1cblxuLmlvbi1jb250ZW50IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5BYnNvbHV0ZS1DZW50ZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICAvL292ZXJmbG93OiBhdXRvO1xuICBtYXJnaW46IGF1dG87XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICBib3R0b206IDA7XG4gIHJpZ2h0OiAwO1xufVxuaW9uLWlucHV0IHtcbiAgLnRleHQtaW5wdXQge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cbn1cblxuLnVzZXJfdXJsX3RleHQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbn1cbi51c2VyX3VybCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHdpZHRoOiAyNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XG4gIHRleHQtYWxpZ246IHN0YXJ0O1xufVxuLnVzZXJfc3ViX2J0biB7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICAtLWJhY2tncm91bmQtaG92ZXI6IGZvcmVzdGdyZWVuO1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiBmb3Jlc3RncmVlbjtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgLS1iYWNrZ3JvdW5kOiBmb3Jlc3RncmVlbjtcbiAgd2lkdGg6IDI1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLm1pZGRsZV9kaXNwbGF5IHtcbiAgaGVpZ2h0OiAzMXB4O1xuICB3aWR0aDogMTU0cHg7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmRpc3BsYXlfdXJsIHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTBweDtcbn1cblxuLnNzbC1sYWJlbCB7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGFsaWduLXNlbGY6IGNlbnRlcjtcbn1cblxuLmljb24ge1xuICAtLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItZm9yZXN0Z3JlZW4sICMyMjhiMjIpICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLXNoYWRlOiB2YXIoLS1pb24tY29sb3ItZm9yZXN0Z3JlZW4tc2hhZGUsICMyMjhiMjIpICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLWlvbi1jb2xvci1mb3Jlc3RncmVlbi10aW50LCAjMjI4YjIyKSAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWlubGluZS1zdGFydDogNDFweDtcbn1cbi5jb2x1bWUge1xuICBoZWlnaHQ6IDI5cHg7XG4gIC8qIG1pbi1oZWlnaHQ6IDBweDsgKi9cbiAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcbiAgcGFkZGluZy10b3A6IDBweDtcbiAgcGFkZGluZy1ib3R0b206IDBweDtcbn1cblxuLm15LWxhYmVsIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuIiwiaW9uLXRpdGxlIHtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tYm90dG9tOiAydmg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1hbGlnbi1jb250ZW50OiBjZW50ZXI7XG4gIC0tZGlzcGxheTogZmxleDtcbiAgLS1mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAtLWFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIC0tanVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIC0taGVpZ2h0OiBcIjEwMCVcIjtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmF5O1xufVxuXG4uaW9uLWNvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuXG4uQWJzb2x1dGUtQ2VudGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgbWFyZ2luOiBhdXRvO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAwO1xuICByaWdodDogMDtcbn1cblxuaW9uLWlucHV0IC50ZXh0LWlucHV0IHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLnVzZXJfdXJsX3RleHQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbn1cblxuLnVzZXJfdXJsIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgd2lkdGg6IDI1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgZ3JheTtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBwYWRkaW5nLWxlZnQ6IDhweDtcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XG59XG5cbi51c2VyX3N1Yl9idG4ge1xuICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOiBmb3Jlc3RncmVlbjtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogZm9yZXN0Z3JlZW47XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIC0tYmFja2dyb3VuZDogZm9yZXN0Z3JlZW47XG4gIHdpZHRoOiAyNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5taWRkbGVfZGlzcGxheSB7XG4gIGhlaWdodDogMzFweDtcbiAgd2lkdGg6IDE1NHB4O1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5kaXNwbGF5X3VybCB7XG4gIGZsb2F0OiBsZWZ0O1xuICBmb250LXNpemU6IDEwcHg7XG59XG5cbi5zc2wtbGFiZWwge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBhbGlnbi1zZWxmOiBjZW50ZXI7XG59XG5cbi5pY29uIHtcbiAgLS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLWZvcmVzdGdyZWVuLCAjMjI4YjIyKSAhaW1wb3J0YW50O1xuICAtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLWZvcmVzdGdyZWVuLXNoYWRlLCAjMjI4YjIyKSAhaW1wb3J0YW50O1xuICAtLWlvbi1jb2xvci10aW50OiB2YXIoLS1pb24tY29sb3ItZm9yZXN0Z3JlZW4tdGludCwgIzIyOGIyMikgIWltcG9ydGFudDtcbiAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDQxcHg7XG59XG5cbi5jb2x1bWUge1xuICBoZWlnaHQ6IDI5cHg7XG4gIC8qIG1pbi1oZWlnaHQ6IDBweDsgKi9cbiAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcbiAgcGFkZGluZy10b3A6IDBweDtcbiAgcGFkZGluZy1ib3R0b206IDBweDtcbn1cblxuLm15LWxhYmVsIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");







let HomePage = class HomePage {
    constructor(alertController, navCtrl, router, storage, toastController) {
        this.alertController = alertController;
        this.navCtrl = navCtrl;
        this.router = router;
        this.storage = storage;
        this.toastController = toastController;
        this.Url = "";
        this.sslToggled = false;
        this.sslValue = "http://";
        storage.get('BM_SSL_URL').then((val) => {
            if (val && val != '') {
                this.router.navigate(['/login']);
            }
        });
    }
    presentToast() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Please provide valid url.',
                duration: 2000
            });
            toast.present();
        });
    }
    gologin() {
        if (this.Url != '') {
            this.storage.set('BM_SSL_URL', this.sslValue + this.Url);
            this.router.navigate(['/login']);
        }
        else {
            this.presentToast();
        }
    }
    ChangeSSLValue() {
        this.sslValue = this.sslToggled ? "https://" : "http://";
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
        styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map