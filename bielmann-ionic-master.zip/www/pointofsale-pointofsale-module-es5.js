(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pointofsale-pointofsale-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pointofsale/pointofsale.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pointofsale/pointofsale.page.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Point Of Sale</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"container\">\n  <ion-searchbar></ion-searchbar>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"4\" style=\"--ion-grid-column-padding:0px;\">\n        <ion-row class=\"question_list\">\n          <span class=\"que_list_item_sel\">Global Tag</span>\n          <span class=\"que_list_item\">Laravell</span>\n          <span class=\"que_list_item\">Laravell 3</span>\n          <span class=\"que_list_item\">Laravell 4</span>\n          <span class=\"que_list_item\">Laravell 5</span>\n          <span class=\"que_list_item\">Laravell 6</span>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"8\">\n        <ion-row class=\"detail_box\">\n          <span\n            class=\"detail_box_span\">LoreumipsumumipsumLoreumipsumLoreumipsum</span>\n        </ion-row>\n        <ion-row class=\"detail_box2\">\n          <span\n            class=\"detail_box_span\"></span>\n        </ion-row>\n\n        <ion-row class=\"detail_box3\">\n          <span\n            class=\"detail_box_span\">1</span>\n        </ion-row>\n        <ion-row class=\"detail_box4\">\n          <span\n            class=\"detail_box_span\">Amesterdam</span>\n        </ion-row>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/pointofsale/pointofsale.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pointofsale/pointofsale.module.ts ***!
  \***************************************************/
/*! exports provided: PointofsalePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PointofsalePageModule", function() { return PointofsalePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pointofsale_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pointofsale.page */ "./src/app/pointofsale/pointofsale.page.ts");







var routes = [
    {
        path: '',
        component: _pointofsale_page__WEBPACK_IMPORTED_MODULE_6__["PointofsalePage"]
    }
];
var PointofsalePageModule = /** @class */ (function () {
    function PointofsalePageModule() {
    }
    PointofsalePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_pointofsale_page__WEBPACK_IMPORTED_MODULE_6__["PointofsalePage"]]
        })
    ], PointofsalePageModule);
    return PointofsalePageModule;
}());



/***/ }),

/***/ "./src/app/pointofsale/pointofsale.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pointofsale/pointofsale.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".container {\n  -webkit-box-flex: 1;\n          flex: 1;\n  background-color: #f5f4f4;\n}\n\n.question_list {\n  margin-top: 10px;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  display: -webkit-box;\n  display: flex;\n  border: 1px solid;\n}\n\n.que_list_item_sel {\n  min-height: 45px;\n  background-color: #27c427;\n  padding: 5px;\n}\n\n.que_list_item {\n  min-height: 45px;\n  padding: 5px;\n  background-color: white;\n  border-bottom: 0.5px gray solid;\n}\n\n.detail_box {\n  font-size: 14px;\n  min-height: 200px;\n  border: 1px solid black;\n  padding: 8px;\n  text-align: start;\n}\n\n.detail_box2 {\n  font-size: 14px;\n  min-height: 80px;\n  border: 1px solid black;\n  padding: 8px;\n  text-align: start;\n}\n\n.detail_box3 {\n  font-size: 14px;\n  min-height: 80px;\n  border: 1px solid black;\n  padding: 8px;\n  text-align: start;\n}\n\n.detail_box4 {\n  margin-top: 20px;\n  font-size: 14px;\n  min-height: 80px;\n  border: 1px solid black;\n  padding: 8px;\n  text-align: start;\n}\n\n.detail_box_span {\n  padding: 5px;\n  width: 100%;\n  background-color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcG9pbnRvZnNhbGUvRDpcXElvbmljXFxBcHAgSW52ZW50ZXJzXFxiaWVsbWFubi1pb25pYy1tYXN0ZXIvc3JjXFxhcHBcXHBvaW50b2ZzYWxlXFxwb2ludG9mc2FsZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BvaW50b2ZzYWxlL3BvaW50b2ZzYWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO1VBQUEsT0FBQTtFQUNBLHlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQ0NGOztBRENBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSwrQkFBQTtBQ0VGOztBREFBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUNHRjs7QUREQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDSUY7O0FERkE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ0tGOztBREhBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ01GOztBREpBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtBQ09GIiwiZmlsZSI6InNyYy9hcHAvcG9pbnRvZnNhbGUvcG9pbnRvZnNhbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XHJcbiAgZmxleDogMTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjQ1LCAyNDQsIDI0NCk7XHJcbn1cclxuXHJcbi5xdWVzdGlvbl9saXN0IHtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBib3JkZXI6IDFweCBzb2xpZDtcclxufVxyXG5cclxuLnF1ZV9saXN0X2l0ZW1fc2VsIHtcclxuICBtaW4taGVpZ2h0OiA0NXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigzOSwgMTk2LCAzOSk7XHJcbiAgcGFkZGluZzogNXB4O1xyXG59XHJcbi5xdWVfbGlzdF9pdGVtIHtcclxuICBtaW4taGVpZ2h0OiA0NXB4O1xyXG4gIHBhZGRpbmc6IDVweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItYm90dG9tOiAwLjVweCBncmF5IHNvbGlkO1xyXG59XHJcbi5kZXRhaWxfYm94IHtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgbWluLWhlaWdodDogMjAwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIHRleHQtYWxpZ246IHN0YXJ0O1xyXG59XHJcbi5kZXRhaWxfYm94MiB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDgwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIHRleHQtYWxpZ246IHN0YXJ0O1xyXG59XHJcbi5kZXRhaWxfYm94MyB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDgwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIHRleHQtYWxpZ246IHN0YXJ0O1xyXG59XHJcbi5kZXRhaWxfYm94NCB7XHJcbiAgbWFyZ2luLXRvcDogMjBweDtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgbWluLWhlaWdodDogODBweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XHJcbn1cclxuLmRldGFpbF9ib3hfc3BhbiB7XHJcbiAgcGFkZGluZzogNXB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcbiIsIi5jb250YWluZXIge1xuICBmbGV4OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNGY0O1xufVxuXG4ucXVlc3Rpb25fbGlzdCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGJvcmRlcjogMXB4IHNvbGlkO1xufVxuXG4ucXVlX2xpc3RfaXRlbV9zZWwge1xuICBtaW4taGVpZ2h0OiA0NXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjdjNDI3O1xuICBwYWRkaW5nOiA1cHg7XG59XG5cbi5xdWVfbGlzdF9pdGVtIHtcbiAgbWluLWhlaWdodDogNDVweDtcbiAgcGFkZGluZzogNXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLWJvdHRvbTogMC41cHggZ3JheSBzb2xpZDtcbn1cblxuLmRldGFpbF9ib3gge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1pbi1oZWlnaHQ6IDIwMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgcGFkZGluZzogOHB4O1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbn1cblxuLmRldGFpbF9ib3gyIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtaW4taGVpZ2h0OiA4MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgcGFkZGluZzogOHB4O1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbn1cblxuLmRldGFpbF9ib3gzIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtaW4taGVpZ2h0OiA4MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgcGFkZGluZzogOHB4O1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbn1cblxuLmRldGFpbF9ib3g0IHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtaW4taGVpZ2h0OiA4MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgcGFkZGluZzogOHB4O1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbn1cblxuLmRldGFpbF9ib3hfc3BhbiB7XG4gIHBhZGRpbmc6IDVweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pointofsale/pointofsale.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pointofsale/pointofsale.page.ts ***!
  \*************************************************/
/*! exports provided: PointofsalePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PointofsalePage", function() { return PointofsalePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var PointofsalePage = /** @class */ (function () {
    function PointofsalePage() {
    }
    PointofsalePage.prototype.ngOnInit = function () {
    };
    PointofsalePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-pointofsale',
            template: __webpack_require__(/*! raw-loader!./pointofsale.page.html */ "./node_modules/raw-loader/index.js!./src/app/pointofsale/pointofsale.page.html"),
            styles: [__webpack_require__(/*! ./pointofsale.page.scss */ "./src/app/pointofsale/pointofsale.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PointofsalePage);
    return PointofsalePage;
}());



/***/ })

}]);
//# sourceMappingURL=pointofsale-pointofsale-module-es5.js.map